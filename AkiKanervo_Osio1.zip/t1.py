value1 = int(input("Syötä ensimmäinen arvo: "))

print("\n\n\nEnsimmäinen arvo:", value1, "\n")

value2 = int(input("Syötä toinen arvo: "))

print("\n\n\nEnsimmäinen arvo:", value1, "\nToinen arvo:", value2, "\n")
print("Summa:", (value1 + value2), "\nErotus:", (value1 - value2), "\nTulo:", (value1 * value2), "\nOsamäärä:", (value1 / value2))